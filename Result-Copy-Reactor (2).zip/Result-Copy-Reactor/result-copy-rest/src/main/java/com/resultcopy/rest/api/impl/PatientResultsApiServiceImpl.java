package com.resultcopy.rest.api.impl;


import com.resultcopy.PatientDto;
import com.resultcopy.PatientResultDto;
import com.resultcopy.rest.api.PatientResultsApiService;

import com.resultcopy.rest.api.NotFoundException;
import com.resultcopy.service.model.Patient;
import com.resultcopy.service.dao.PatientDAO;
import com.resultcopy.service.impl.PatientDAOImpl;
import com.resultcopy.service.serviceimpl.PatientServiceImpl;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2021-06-10T12:22:56.778Z[GMT]")public class PatientResultsApiServiceImpl extends PatientResultsApiService {
    @Override
    public Response patientResultsPatientIdGet(String patientId, SecurityContext securityContext) throws NotFoundException {
        PatientServiceImpl patientService = new PatientServiceImpl();
        PatientResultDto patient =patientService.getPatientDetails(patientId);

        //patient.setChild();
        return Response.ok().entity(patient).build();
    }
}
