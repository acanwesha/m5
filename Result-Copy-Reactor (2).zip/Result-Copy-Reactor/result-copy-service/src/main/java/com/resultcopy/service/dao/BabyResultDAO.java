package com.resultcopy.service.dao;


import com.resultcopy.BabyResultDto;
import com.resultcopy.service.model.BabyResult;
import com.resultcopy.service.model.Patient;

public interface BabyResultDAO {

    BabyResult getBabyPatientByChildId(Integer childId);
    public void createBabyResult(BabyResultDto babyResultDto);
}
