package com.resultcopy.service.dao;

import com.resultcopy.service.model.Category;

import java.util.List;

public interface CategoryDAO {
    public List<Category> getCategories();
}
