package com.resultcopy.service.serviceimpl;

import com.resultcopy.*;
import com.resultcopy.service.dao.*;
import com.resultcopy.service.impl.*;
import com.resultcopy.service.model.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PatientServiceImpl {

    PatientDAO dao = new PatientDAOImpl();
    ChildDAO childDAO = new ChildDAOImpl() ;
    ResultDAO resultDAO = new ResultDAOImpl();

    public PatientResultDto getPatientDetails(String patientId){
        List<CategoryDto> categoryDtoList = new ArrayList<>();

        Patient p =dao.getPatientById(Integer.parseInt(patientId));
        PatientDto pDto = new PatientDto();
        pDto.setPatientId(p.getPatientDetails().getId());
        pDto.setFin(p.getPatientDetails().getFin());
        pDto.setFirstName(p.getPatientDetails().getFirstName());
        pDto.setLastName(p.getPatientDetails().getLastName());
        pDto.setMrn(p.getPatientDetails().getMrn());


        List<PatientDetails> patientDetailsList = childDAO.getPatientById(Integer.parseInt(patientId));

        PatientDto childDetails  = null;
        //List<PatientDto> childDetailsList = new ArrayList<>();

        ChildDto childDto = null;
        List<ChildDto> childDtoList = new ArrayList<>();
        BabyResultDAO babyResultDAO = new BabyResultDAOImpl();
        //my exp

        for(PatientDetails patientDetail:patientDetailsList){
            childDto = new ChildDto();
            childDto.setFin(patientDetail.getFin());
            childDto.setChildId(patientDetail.getId());
            childDto.setFirstName(patientDetail.getFirstName());
            childDto.setLastName(patientDetail.getLastName());
            childDto.setMrn(patientDetail.getMrn());

            BabyResult br = babyResultDAO.getBabyPatientByChildId(childDto.getChildId());
            CategoryDAO categoryDAO=new CategoryDAOImpl();
            List<Category> categoryList = categoryDAO.getCategories();
            CategoryDto categoryDto=null;
            ResultDAO resultDAO=new ResultDAOImpl();
            //if copied
            if(null!=br){
                childDto.setResultCopiedDate(br.getDateTime());
            }else{
                for(Category category:categoryList){
                    categoryDto=new CategoryDto();
                    categoryDto.setCategoryID(category.getId());
                    categoryDto.setCategory_name(category.getDisplayName());
                    List<Result> resultList = resultDAO.getCategories(category.getId());
                    List<ResultDto> resultDtoList = new ArrayList<>();
                    ResultDto resultDto=null;

                    for(Result result :resultList){

                        resultDto = new ResultDto();
                        resultDto.setResultId(result.getId());
                        resultDto.setResultName(result.getDisplayName());

                        List<PatientResult> patientResultsList =resultDAO.getChildValueById(Integer.parseInt(patientId));
                         ChildResultDto childResultDto = null;
                         List<ChildResultDto> childResultDtoList = new ArrayList<>();
                         System.out.println("childResultDtoList Size :"+childResultDtoList.size());
                        for(PatientResult pr:patientResultsList){
                            if(result.getId()==pr.getResultId()){
                                childResultDto = new ChildResultDto();
                                childResultDto.setChildId(pr.getChildId());
                                childResultDto.setValue(pr.getValue());
                                childResultDtoList.add(childResultDto);
                                System.out.println("ChildId :"+childResultDto.getChildId());
                                System.out.println("Value :"+childResultDto.getValue());
                            }

                        }
                        resultDto.setChildResult(childResultDtoList);
                        resultDtoList.add(resultDto);
                    }
                    categoryDto.setResult(resultDtoList);
                    categoryDtoList.add(categoryDto);
                }
            }

            childDtoList.add(childDto);
        }

        PatientResultDto patient = new PatientResultDto();
        patient.setPatient(pDto);
        patient.setChild(childDtoList);
        patient.setCategory(categoryDtoList);

        return patient;
    }
}
