package com.resultcopy;

import lombok.Getter;
import lombok.Setter;
import org.joda.time.DateTime;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class PatientResultDto {
    private PatientDto patient = new PatientDto();
    private List<ChildDto> child = new ArrayList<>();
    private List<CategoryDto> category = new ArrayList<>();


}
