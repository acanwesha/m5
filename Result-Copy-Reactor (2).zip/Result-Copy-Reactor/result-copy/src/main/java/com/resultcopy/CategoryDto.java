package com.resultcopy;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class CategoryDto implements Serializable {
    private int categoryID;

    private String category_name;

    private List<ResultDto> result = new ArrayList<>();
}
